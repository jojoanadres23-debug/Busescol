# BusesCol — Android game skeleton

Open in Android Studio and build.
