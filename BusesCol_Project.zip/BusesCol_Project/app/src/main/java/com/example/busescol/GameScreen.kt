package com.example.busescol
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.isActive
import kotlin.random.Random
@Composable
fun GameScreen() {
    var size by remember { mutableStateOf(IntSize(1080,1920)) }
    val bus = remember { Bus(position = Offset(200f,1200f)) }
    var score by remember { mutableStateOf(0) }
    var lives by remember { mutableStateOf(3) }
    val obstacles = remember { mutableStateListOf<Obstacle>() }
    val passengers = remember { mutableStateListOf<Passenger>() }
    LaunchedEffect(true) { repeat(5){ obstacles.add(randomObstacle(size)); passengers.add(randomPassenger(size)) } }
    LaunchedEffect(Unit) {
        val targetFps = 60
        val timePerFrame = 1000L / targetFps
        var last = System.currentTimeMillis()
        while (isActive) {
            val now = System.currentTimeMillis()
            val dt = (now - last)/1000f
            last = now
            val moveY = 300f * dt
            for (o in obstacles) { o.position = Offset(o.position.x, o.position.y + moveY); if (o.position.y > size.height + 200) o.position = Offset(Random.nextFloat()*(size.width - o.width), -200f) }
            for (p in passengers) { p.position = Offset(p.position.x, p.position.y + moveY); if (p.position.y > size.height + 200) p.position = Offset(Random.nextFloat()*(size.width - 50), -200f) }
            obstacles.toList().forEach { o -> if (rectsIntersect(bus,o)) { lives -= 1; o.position = Offset(Random.nextFloat()*(size.width - o.width), -400f) } }
            passengers.toList().forEach { p -> if (!p.picked && pointInBus(bus,p.position)){ p.picked = true; score += 10 } }
            kotlinx.coroutines.delay(timePerFrame)
        }
    }
    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize().pointerInput(Unit){ detectTapGestures { pos -> val centerX = size.width/2f; val delta = if (pos.x < centerX) -1 else 1; bus.position = Offset(x = kotlin.math.max(0f, kotlin.math.min(size.width - bus.width, bus.position.x + delta * 150f)), y = bus.position.y) } }, onDraw = { size = IntSize(size.width,size.height); drawGame(this,size,bus,obstacles,passengers) })
        androidx.compose.foundation.layout.Column(modifier = Modifier.align(Alignment.TopStart)) { Text(text = "Puntaje: $score"); Text(text = "Vidas: $lives") }
        if (lives <= 0) { Text(text = "Juego Terminado", modifier = Modifier.align(Alignment.Center)) }
    }
}
fun randomObstacle(size: IntSize) = Obstacle(position = Offset(Random.nextFloat()*(size.width - 100), Random.nextFloat() * -size.height))
fun randomPassenger(size: IntSize) = Passenger(position = Offset(Random.nextFloat()*(size.width - 50), Random.nextFloat() * -size.height))
fun rectsIntersect(bus: Bus, ob: Obstacle): Boolean {
    val bx1 = bus.position.x; val by1 = bus.position.y; val bx2 = bx1 + bus.width; val by2 = by1 + bus.height
    val ox1 = ob.position.x; val oy1 = ob.position.y; val ox2 = ox1 + ob.width; val oy2 = oy1 + ob.height
    return bx1 < ox2 && bx2 > ox1 && by1 < oy2 && by2 > oy1
}
fun pointInBus(bus: Bus, p: Offset) = p.x >= bus.position.x && p.x <= bus.position.x + bus.width && p.y >= bus.position.y && p.y <= bus.position.y + bus.height
fun drawGame(drawScope: DrawScope, size: IntSize, bus: Bus, obstacles: List<Obstacle>, passengers: List<Passenger>) {
    with(drawScope) { drawContext.canvas.nativeCanvas.drawColor(android.graphics.Color.LTGRAY) }
}
