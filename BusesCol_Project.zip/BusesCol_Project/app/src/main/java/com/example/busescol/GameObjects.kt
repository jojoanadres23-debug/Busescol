package com.example.busescol
import androidx.compose.ui.geometry.Offset
data class Bus(var position: Offset, var speed: Float = 300f, var width: Float = 150f, var height: Float = 80f)
data class Obstacle(var position: Offset, val width: Float = 80f, val height: Float = 80f)
data class Passenger(var position: Offset, var picked: Boolean = false)
