// Top-level build file - minimal
plugins { kotlin("jvm") version "1.9.0" apply false }
